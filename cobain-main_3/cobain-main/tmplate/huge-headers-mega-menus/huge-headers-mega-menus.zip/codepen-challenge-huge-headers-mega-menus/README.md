# Codepen Challenge: Huge Headers/Mega Menus

A Pen created on CodePen.io. Original URL: [https://codepen.io/Sicontis/pen/OJzOWxq](https://codepen.io/Sicontis/pen/OJzOWxq).

Missed last week's challenge Mega Menus. Combined it with this week's challenge Huge Headers to make a responsive full screen landing/hero page with a overlay menu for a travel website.