# Animated Tab Bar v.2

A Pen created on CodePen.io. Original URL: [https://codepen.io/abxlfazl/pen/OJbEbxL](https://codepen.io/abxlfazl/pen/OJbEbxL).

Designed by: Hoang Nguyen

Original image: https://dribbble.com/shots/5919154-Tab-Bar-Label-Micro-Interaction