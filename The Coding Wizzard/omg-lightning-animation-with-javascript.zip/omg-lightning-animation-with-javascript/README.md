# OMG !! Lightning Animation With Javascript😮😮

A Pen created on CodePen.io. Original URL: [https://codepen.io/aman_here10/pen/jOvmGrV](https://codepen.io/aman_here10/pen/jOvmGrV).

Heyy.. 
Hope you Enjoyed this......
if you like this work pls drop your valuable comment 
Thankyou....!!!

-Aman Kumar Rajput