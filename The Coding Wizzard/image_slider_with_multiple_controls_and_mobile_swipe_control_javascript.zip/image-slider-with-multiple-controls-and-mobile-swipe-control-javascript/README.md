# Image slider with multiple controls and mobile swipe control (Javascript)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Akimzzy/pen/JjGKMoX](https://codepen.io/Akimzzy/pen/JjGKMoX).

