# Daily UI #008 - 404 Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/rafaelavlucas/pen/NWWQNjZ](https://codepen.io/rafaelavlucas/pen/NWWQNjZ).

