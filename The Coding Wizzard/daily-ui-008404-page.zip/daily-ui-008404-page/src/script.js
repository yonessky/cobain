        // Parallax Code
        var scene = document.getElementById('scene');
        var parallax = new Parallax(scene);