# Animated Continuous Sections with GSAP Observer

A Pen created on CodePen.io. Original URL: [https://codepen.io/GreenSock/pen/XWzRraJ](https://codepen.io/GreenSock/pen/XWzRraJ).

